DIY Backyard Lab starter for ClickBank-focused content.

Topics:
- Gardening -> Aquaponics 4 You
- Woodworking -> Ted's Woodworking
- Energy -> Energy Revolution System

No database. Static content only.